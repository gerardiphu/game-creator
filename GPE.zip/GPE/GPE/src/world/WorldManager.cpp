#include "WorldManager.h"
#include "EngineManager.h"
#include "HeightFunction.h"
#define engineManager GPE::EngineManager::getSingleton()
namespace GPE {
/*********************************************/
WorldManager::WorldManager() {
	isPlayerMoving = false;
	changePlayerAnimation = false;
	cameraYaw = 0;
	initialise();
}
/*********************************************/
WorldManager::~WorldManager() {
	
}
/*********************************************/
void WorldManager::tick() {
	/* Keep character from intersecting through the floor! */
	Ogre::Vector3 charPosition = pcModelNode->getPosition();
	Ogre::Vector3 cameraNodePosition = cameraNode->getPosition();
	charPosition.y = HeightFunction::getTerrainHeight(charPosition.x, charPosition.z);
	pcModelNode->setPosition(charPosition);
	/* Keep the camera on the pc. */
	cameraNode->setPosition(pcModelNode->getPosition() + Ogre::Vector3(0, 5, 0));
	cameraNode->resetOrientation();
	cameraNode->pitch(Ogre::Degree(cameraPitch), Ogre::Node::TS_LOCAL);
	cameraNode->yaw(Ogre::Degree(cameraYaw), Ogre::Node::TS_WORLD);
	cameraNode->translate(Ogre::Vector3(0, 0, cameraZoom), Ogre::Node::TS_LOCAL);
}
/*********************************************/
void WorldManager::initialise() {
	/* Initialise the world scene manager. */
	sceneManager = Ogre::Root::getSingleton().createSceneManager(Ogre::ST_EXTERIOR_CLOSE);
	sceneManager->setAmbientLight(Ogre::ColourValue(0, 0, 0));
	sceneManager->setShadowTechnique(Ogre::SHADOWTYPE_TEXTURE_MODULATIVE);
	/* World scene shadow camera setup. */
       // 3 textures per directional light
       mOgreSceneManager->setShadowTechnique(Ogre::SHADOWTYPE_TEXTURE_ADDITIVE_INTEGRATED);
       //Ogre::MaterialManager::getSingleton().setDefaultTextureFiltering(Ogre::TFO_ANISOTROPIC);
       mOgreSceneManager->setShadowTextureCountPerLightType(Ogre::Light::LT_DIRECTIONAL, 3);
       mOgreSceneManager->setShadowTextureSettings(2048, 3, Ogre::PF_FLOAT32_R);
       mOgreSceneManager->setShadowTextureSelfShadow(true);
       mOgreSceneManager->setShadowCasterRenderBackFaces(true);
       mOgreSceneManager->setShadowFarDistance(200.0f);
       // Set up caster material - this is just a standard depth/shadow map caster
       mOgreSceneManager->setShadowTextureCasterMaterial("PSSM/shadow_caster");
       // shadow camera setup:
       mPSSMSetup = new Ogre::PSSMShadowCameraSetup();
       mPSSMSetup->setSplitPadding(0.05f);
       mPSSMSetup->calculateSplitPoints(3, mCameraMgr->getCamera()->getNearClipDistance(), mOgreSceneManager->getShadowFarDistance());
       mPSSMSetup->setOptimalAdjustFactor(0, 3.0f);
       mPSSMSetup->setOptimalAdjustFactor(1, 1.0f);
       mPSSMSetup->setOptimalAdjustFactor(2, 0.5f);

       mOgreSceneManager->setShadowCameraSetup(Ogre::ShadowCameraSetupPtr(mPSSMSetup));

       // get split points
       Ogre::Vector4 splitPoints;
       const Ogre::PSSMShadowCameraSetup::SplitPointList& splitPointList = mPSSMSetup->getSplitPoints();
       for (type::s32 i = 0; i < 3; ++i)
          splitPoints[i] = splitPointList[i];

       // prepare materials for pssm
       Ogre::ResourceManager::ResourceMapIterator materials = Ogre::MaterialManager::getSingleton().getResourceIterator();
       while (materials.hasMoreElements())
       {
          Ogre::Material *material = static_cast<Ogre::Material*>(materials.getNext().getPointer());
          Ogre::Pass *pass = material->getTechnique(0)->getPass("pssm");
          if (pass != NULL)
             pass->getFragmentProgramParameters()->setNamedConstant("pssmSplitPoints", splitPoints);
       }

	Ogre::PSSMShadowCameraSetup * shadowCameraSetup = new Ogre::PSSMShadowCameraSetup();
	/* 3 textures per directional light */
	sceneManager->setShadowTextureCountPerLightType(Ogre::Light::LT_DIRECTIONAL, 3);
	sceneManager->setShadowTextureSettings(512, 3, Ogre::PF_FLOAT32_R);
	sceneManager->setShadowTextureSelfShadow(true);
	/* Set up caster material - this is just a standard depth/shadow map caster */
	sceneManager->setShadowTextureCasterMaterial("PSSM/shadow_caster");
	/* shadow camera setup */
	shadowCameraSetup->calculateSplitPoints(3, 1, 0);
	shadowCameraSetup->setSplitPadding(10);
	shadowCameraSetup->setOptimalAdjustFactor(0, 2);
	shadowCameraSetup->setOptimalAdjustFactor(1, 1);
	shadowCameraSetup->setOptimalAdjustFactor(2, 0.5);
	sceneManager->setShadowCameraSetup(Ogre::ShadowCameraSetupPtr(shadowCameraSetup));
	/* Initialise the world camera and viewport. */
	camera = sceneManager->createCamera("worldCamera");
	viewport = engineManager.getRenderWindow()->addViewport(camera);
	/* Blue sky background color. */
	viewport->setBackgroundColour(Ogre::ColourValue(0.47f, 0.67f, 0.96f));
	camera->setAspectRatio(Ogre::Real(viewport->getActualWidth()) / Ogre::Real(viewport->getActualHeight()));
	camera->setNearClipDistance(1);
	camera->setFarClipDistance(0.0f);
	/* Set up lighting. */
	Ogre::Light *light = sceneManager->createLight("Sun");
	light->setType(Ogre::Light::LT_DIRECTIONAL);
	light->setDirection(Ogre::Vector3(0.0f, -0.5f, 1.0f));
	sceneManager->setAmbientLight(Ogre::ColourValue(0.5f, 0.5f, 0.5f));
	/* Setup the fog up to 1000 units away. */
	sceneManager->setShadowFarDistance(1000);
	/* Load the terrain. */
	sceneManager->setWorldGeometry("terrain.cfg");
	/* Load the skybox. */
	sceneManager->setSkyBox(true, "skyBox", 1000, true);
	/* Setup the height function, so the Y values of trees can be calculated when they are placed on the terrain. */
	HeightFunction::initialize(sceneManager);
	/* Load gilead */
	pcModel = sceneManager->createEntity("gilead", "gilead.mesh");
	pcModel->setCastShadows(true);
	/* Set idle and walk animations. */
    animationState = pcModel->getAnimationState("idle");
    animationState->setLoop(true);
    animationState->setEnabled(true);
	/* Get height to place character, camera, etc. */
	Ogre::Vector3 position;
	position.x = 750;
	position.z = 750;
	position.y = HeightFunction::getTerrainHeight(position.x, position.z);
	pcModelNode = sceneManager->getRootSceneNode()->createChildSceneNode("pcModelNode");
	pcModelNode->setPosition(position);
    pcModelNode->attachObject(pcModel);
	pcModelNode->scale(Ogre::Vector3(0.005, 0.005, 0.005));
	cameraNode = sceneManager->getRootSceneNode()->createChildSceneNode("worldCameraNode");
	cameraNode->attachObject(camera);
	loadGrass();
	loadTrees();
}
/*********************************************/
void WorldManager::createGrassMesh(void) {
	/* Declare all of our grass variables. */
	const float width = 25.0f;
	const float height = 30.0f;
 	Ogre::ManualObject grass("GrassObject");
 	Ogre::Vector3 vec(width / 2, 0, 0);
	Ogre::Quaternion rot;
	rot.FromAngleAxis(Ogre::Degree(60), Ogre::Vector3::UNIT_Y);
 	/* Start defining our manual object. */
	grass.begin("yellow_grass", Ogre::RenderOperation::OT_TRIANGLE_LIST);
 	/* Define the 4 vertices of our quad and set to the texture coordinates. */
	for(int i = 0; i < 3; ++i) {
		grass.position(-vec.x, height, -vec.z);
		grass.textureCoord(0, 0);
 		grass.position(vec.x, height, vec.z);
		grass.textureCoord(1, 0);
 		grass.position(-vec.x, 0, -vec.z);
		grass.textureCoord(0, 1);
 		grass.position(vec.x, 0, vec.z);
		grass.textureCoord(1, 1);
 		int offset = i * 4;
 		grass.triangle(offset, offset + 3, offset + 1);
		grass.triangle(offset, offset + 2, offset + 3);
 		/* rotate the next quad */
		vec = rot * vec;
	}
	grass.end();
 	/* Create an actual mesh out of this object. */
	grass.convertToMesh("GrassBladesMesh");
}
/*********************************************/
void WorldManager::loadGrass() {
	createGrassMesh();
 	Ogre::Entity* grass = sceneManager->createEntity("grass", "GrassBladesMesh");
	Ogre::StaticGeometry* sg = sceneManager->createStaticGeometry("GrassArea");
	const int size = 1500;
	const int amount = 50;
 	sg->setRegionDimensions(Ogre::Vector3(size, size, size));
	sg->setOrigin(Ogre::Vector3(0, 0, 0));
 	for(int x = -size / 2; x < size /2; x += (size/amount)) {
		for(int z = -size / 2; z < size / 2; z += (size/amount)) {
			Ogre::Real r = size / float(amount / 2);
			Ogre::Vector3 pos(x + 750 + Ogre::Math::RangeRandom(-r, r), HeightFunction::getTerrainHeight(x, z) - 25, z + 750 + Ogre::Math::RangeRandom(-r, r));
			Ogre::Vector3 scale(Ogre::Math::RangeRandom(0.3f, 0.7f), Ogre::Math::RangeRandom(0.3f, 0.7f), Ogre::Math::RangeRandom(0.3f, 0.7f));
			Ogre::Quaternion orientation;
			orientation.FromAngleAxis(Ogre::Degree(Ogre::Math::RangeRandom(0, 359)), Ogre::Vector3::UNIT_Y);
			sg->addEntity(grass, pos, orientation, scale);
		}
		sg->build();
	}
}
/*********************************************/
void WorldManager::loadTrees() {
	/* Randomly place copies of the tree on the terrain */
    char name[16];
    for(int i = 0; i < 333; i++) {
		float rx = Ogre::Math::RangeRandom(0, 1500);
		float rz = Ogre::Math::RangeRandom(0, 1500);
		sprintf(name, "Tree%d", i);
		Ogre::Entity *ent = sceneManager->createEntity(name, "tree1.mesh");
		Ogre::Real terrainHeight = HeightFunction::getTerrainHeight(rx, rz);
		Ogre::SceneNode *mCurrentObject = sceneManager->getRootSceneNode()->createChildSceneNode(Ogre::String(name) + "Node", Ogre::Vector3(rx,terrainHeight,rz));
		mCurrentObject->attachObject(ent);
		mCurrentObject->setPosition(rx, terrainHeight-25, rz);
		float r = Ogre::Math::RangeRandom(0.03, 0.33);
		mCurrentObject->setScale(r, r, r);
		mCurrentObject->yaw(Ogre::Degree(Ogre::Math::RangeRandom(0, 360)));
    }
}
} /* Namespace GPE */
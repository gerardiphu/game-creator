extern "C" {
	#include "lua.h"
	#include "lauxlib.h"
	#include "lualib.h"
}
#include "Ogre.h"
#include "CEGUI.h"
#include "CEGUILua.h"
#include "OgreCEGUIRenderer.h"
#include "EngineManager.h"
#include "GuiManager.h"
#include "WorldManager.h"
#define engineManager GPE::EngineManager::getSingleton()
namespace GPE { 
/*********************************************/
GuiManager::GuiManager() {
	initialise();
}
/*********************************************/
GuiManager::~GuiManager() {
	delete ceguiSystem;
	delete scriptModule;
	delete guiRenderer;
}
/*********************************************/
void GuiManager::tick() {
	rttCameraZ = scriptModule->executeScriptGlobal("getRttCameraZ");
	rttCharacterRotate = scriptModule->executeScriptGlobal("getRttCharacterRotate");
	sceneManager->getCamera("rttCamera")->moveRelative( Ogre::Vector3::NEGATIVE_UNIT_Z * rttCameraZ );
	sceneManager->getSceneNode("modelNode")->yaw( Ogre::Degree(rttCharacterRotate) );
}
/*********************************************/
void GuiManager::initialise() {
	/* Initialise our render to texture scene. */
	sceneManager = Ogre::Root::getSingleton().createSceneManager(Ogre::ST_GENERIC);
	sceneManager->setAmbientLight(Ogre::ColourValue(0, 0, 0));
	sceneManager->setShadowTechnique(Ogre::SHADOWTYPE_TEXTURE_MODULATIVE);
	/* Shadow camera setup. */
	Ogre::LiSPSMShadowCameraSetup * shadowCameraSetup = new Ogre::LiSPSMShadowCameraSetup();
	shadowCameraSetup->setOptimalAdjustFactor(33);
	sceneManager->setShadowCameraSetup(Ogre::ShadowCameraSetupPtr(shadowCameraSetup));
	sceneManager->setShadowTextureSize(512);
	sceneManager->setShadowTextureSettings(512, 1);
	sceneManager->setShadowFarDistance(500);
	sceneManager->setShadowColour(Ogre::ColourValue(0.5, 0.5, 0.5));
	sceneManager->setShadowTexturePixelFormat(Ogre::PF_L8);
	/* Set up our Lua State object. */
	lua_State* luaState = scriptModule->getLuaState();
	/* Set up CEGUI. */
	guiRenderer = new CEGUI::OgreCEGUIRenderer(engineManager.getRenderWindow(),Ogre::RENDER_QUEUE_OVERLAY,false,3000,engineManager.getWorldManager()->getSceneManager());
	scriptModule = new CEGUI::LuaScriptModule();
	ceguiSystem = new CEGUI::System(guiRenderer,NULL,NULL,scriptModule,"gui.config","data//config//gui.log");
	renderCharacter();
}
/*********************************************/
void GuiManager::renderCharacter() {
	Ogre::String name = "gilead";
	CEGUI::URect area =	CEGUI::URect(CEGUI::UDim(0.689152f, 0.0f), CEGUI::UDim(0.0881348f, 0.0f), CEGUI::UDim(0.928344f, 0.0f), CEGUI::UDim(0.721856f,0.0f));
    /* Scene setup. */
	Ogre::Entity *model = sceneManager->createEntity(name, name + ".mesh");
	Ogre::SceneNode *modelNode = sceneManager->getRootSceneNode()->createChildSceneNode("modelNode",Ogre::Vector3(0, 0, 0));
    modelNode->attachObject(model);
	/* Set up lights. */
	Ogre::Light* rttPointLight = sceneManager->createLight("rttPointLight");
    rttPointLight->setType(Ogre::Light::LT_POINT);
    rttPointLight->setPosition(0, -400, 2500);
    rttPointLight->setDiffuseColour(1.0, 1.0, 1.0);
    rttPointLight->setSpecularColour(1.0, 1.0, 1.0);
	/* Set Idle animation. */
	animationState = model->getAnimationState("idle");
    animationState->setLoop(true);
    animationState->setEnabled(true);
    /* Texture setup. */
	Ogre::RenderTexture *rttTexture = Ogre::Root::getSingleton().getTextureManager()->
		createManual("rttTexture", "Default", Ogre::TEX_TYPE_2D, 512, 512, 0, Ogre::PF_B8G8R8A8, Ogre::TU_RENDERTARGET)->
		getBuffer()->getRenderTarget();
	Ogre::Camera *rttCamera = sceneManager->createCamera("rttCamera");
    rttCamera->setPosition(0, -400, 5500);
    rttCamera->lookAt(0, -400, 0);
	Ogre::Viewport *rttViewport = rttTexture->addViewport(rttCamera);
    rttViewport->setOverlaysEnabled(false);
    rttViewport->setClearEveryFrame(true);
	rttViewport->setBackgroundColour(Ogre::ColourValue(0, 0, 0, 0));
	rttCamera->setAspectRatio(rttViewport->getActualWidth() / rttViewport->getActualHeight());
    /* CEGUI setup. */
    CEGUI::Texture *ceguiRttTexture = guiRenderer->createTexture("rttTexture");
    CEGUI::Imageset *rttImageSet = CEGUI::ImagesetManager::getSingleton().createImageset("rttImageset", ceguiRttTexture);
    rttImageSet->defineImage(	"rttImage",
								CEGUI::Point(0.0f, 0.0f),
								CEGUI::Size(ceguiRttTexture->getWidth(), 
								ceguiRttTexture->getHeight()),
								CEGUI::Point(0.0f, 0.0f));
	CEGUI::Window *rttWindow = CEGUI::WindowManager::getSingleton().createWindow("AbaddonLook/StaticImage", "rttWindow");
    rttWindow->setArea(area);
    rttWindow->setProperty("BackgroundImage", CEGUI::PropertyHelper::imageToString(&rttImageSet->getImage("rttImage")));
	ceguiSystem->getGUISheet()->addChildWindow(rttWindow);
	rttWindow->setAlpha(0);
}
} /* Namespace GPE */
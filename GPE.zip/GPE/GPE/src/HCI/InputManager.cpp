#include "Ogre.h"
#include "OIS\OISInputManager.h"
#include "CEGUISystem.h"
#include "CEGUILua.h"
#include "EngineManager.h"
#include "GuiManager.h"
#include "InputManager.h"
#include "WorldManager.h"
#define engineManager GPE::EngineManager::getSingleton()
#define ceguiSystem CEGUI::System::getSingleton()
namespace GPE {
/*********************************************/
InputManager::InputManager() {
	/* Set the keyboard transform to zero. */
	inputTransform = 0;
	/* Set our RttWindow rotate speed. */
	rotateSpeed = 0.01f;
	initialise();
}
/*********************************************/
InputManager::~InputManager() {
	if (oisMouse) {
		delete oisMouse;
	}
	if (oisKeyboard) {
		delete oisKeyboard;
	}
	OIS::InputManager::destroyInputSystem(oisInputManager);
}
/*********************************************/
void InputManager::tick() {
	/* capture mouse and keyboard input. */
	oisMouse->capture();
	oisKeyboard->capture();
	if (inputTransform.x != 0) {
		engineManager.getWorldManager()->getModelNode()->yaw(Ogre::Degree(inputTransform.x * 5));
	} else {
		engineManager.getWorldManager()->getModelNode()->translate(inputTransform, Ogre::Node::TS_LOCAL);
	}
}
/*********************************************/
void InputManager::initialise() {
	/* Set up our windows. */
	unsigned long windowHandle;
	engineManager.getRenderWindow()->getCustomAttribute("WINDOW", &windowHandle);
	OIS::ParamList oisParameterList;
	oisParameterList.insert(OIS::ParamList::value_type("WINDOW", Ogre::StringConverter::toString(windowHandle)));
	oisInputManager = OIS::InputManager::createInputSystem(oisParameterList);
	oisMouse = static_cast<OIS::Mouse*>(oisInputManager->createInputObject(OIS::OISMouse, true ));
	oisKeyboard = static_cast<OIS::Keyboard*>(oisInputManager->createInputObject(OIS::OISKeyboard, true));
	oisMouse->setEventCallback(this);
	oisKeyboard->setEventCallback(this);
}
/*********************************************/
void InputManager::setWindowExtents(int width, int height){
	const OIS::MouseState &oisMouseState = oisMouse->getMouseState();
	oisMouseState.width = width;
	oisMouseState.height = height;
}
/*********************************************/
bool InputManager::mouseMoved(const OIS::MouseEvent &mouseEvent) {
	/* If we are controlling the GUI Camera. */
	if (engineManager.getGameState() == 0) {
		engineManager.getGuiManager()->getSceneManager()->getCamera("rttCamera")->moveRelative( Ogre::Vector3::NEGATIVE_UNIT_Z * (mouseEvent.state.Z.rel) );
	/* Otherwise we are controlling the world camera. */
	} else if (engineManager.getGameState() == 1) {
		/* Setup zoom from mouse wheel which is the z axis of mouse event. */
		engineManager.getWorldManager()->modifyCameraZoom((float) mouseEvent.state.Z.rel / 20.0f);
		/* If we hold down the right mouse button we can rotate the camera. */
		if (mouseEvent.state.buttonDown(OIS::MB_Right)) {
			engineManager.getWorldManager()->modifyCameraYaw((float) mouseEvent.state.X.rel * 0.5f);
			engineManager.getWorldManager()->modifyCameraPitch((float) mouseEvent.state.Y.rel * 0.5f);
		}
	}
	ceguiSystem.injectMouseWheelChange(mouseEvent.state.Z.rel);
	return ceguiSystem.injectMouseMove(mouseEvent.state.X.rel, mouseEvent.state.Y.rel);
}
/*********************************************/
bool InputManager::mousePressed(const OIS::MouseEvent &mouseEvent, OIS::MouseButtonID mouseButton) {
	CEGUI::MouseButton button = CEGUI::NoButton;
	if (mouseButton == OIS::MB_Left) {
		button = CEGUI::LeftButton;
	}
	if (mouseButton == OIS::MB_Middle) {
		button = CEGUI::MiddleButton;
	}
	if (mouseButton == OIS::MB_Right) {
		button = CEGUI::RightButton;
	}
	return ceguiSystem.injectMouseButtonDown(button);
}
/*********************************************/
bool InputManager::mouseReleased(const OIS::MouseEvent &mouseEvent, OIS::MouseButtonID mouseButton) {
	CEGUI::MouseButton button = CEGUI::NoButton;
	if (mouseButton == OIS::MB_Left) {
		button = CEGUI::LeftButton;
	}
	if (mouseButton == OIS::MB_Middle) {
		button = CEGUI::MiddleButton;
	}
	if (mouseButton == OIS::MB_Right) {
		button = CEGUI::RightButton;
	}
	return ceguiSystem.injectMouseButtonUp(button);
}
/*********************************************/
bool InputManager::keyPressed(const OIS::KeyEvent &keyEvent) {
	unsigned int ch = keyEvent.text;
	ceguiSystem.injectKeyDown(keyEvent.key);
	if (engineManager.getGameState() == 1) {
		/* Allow the camera to move around with the arrow/WASD keys. */
		if ((keyEvent.key == OIS::KC_UP) || (keyEvent.key == OIS::KC_W)) {
			inputTransform.z = 1;
		} else if ((keyEvent.key == OIS::KC_DOWN) || (keyEvent.key == OIS::KC_S)) {
			inputTransform.z = -1;
		} else if ((keyEvent.key == OIS::KC_RIGHT) || (keyEvent.key == OIS::KC_D)) {
			inputTransform.x = -1;
		} else if ((keyEvent.key == OIS::KC_LEFT) || (keyEvent.key == OIS::KC_A)) {
			inputTransform.x = 1;
		}
		/* Shift = speed boost. */
		if ((keyEvent.key == OIS::KC_LSHIFT) || (keyEvent.key == OIS::KC_RSHIFT)) {
			inputTransform *= 4;
		} else {
			inputTransform *= 0.5f;
		}
		if (((inputTransform.x != 0) || (inputTransform.z != 0)) && (engineManager.getWorldManager()->getIsPlayerMoving() == false)) {
			engineManager.getWorldManager()->setIsPlayerMoving(true);
			engineManager.getWorldManager()->setChangePlayerAnimation(true);
		}
		if (keyEvent.key == OIS::KC_M) {
			engineManager.getGuiManager()->getScriptModule()->executeScriptGlobal("showMainMenu");
		}
	}
	return ceguiSystem.injectChar(ch);
}
/*********************************************/
bool InputManager::keyReleased(const OIS::KeyEvent &keyEvent) {
	if (engineManager.getGameState() == 1) {
		inputTransform = 0;
		engineManager.getWorldManager()->setIsPlayerMoving(false);
		engineManager.getWorldManager()->setChangePlayerAnimation(true);
	}
	if (keyEvent.key == OIS::KC_ESCAPE) {
		engineManager.setShouldQuit(true);
	} else if (keyEvent.key == OIS::KC_SYSRQ) {
        char scDateTime[100];
        time_t tTime;
        time(&tTime);
        strftime(scDateTime, 100, "screenshot_%m-%d-%Y_%H-%M-%S.png", localtime(&tTime));
		engineManager.getRenderWindow()->writeContentsToFile((Ogre::String)scDateTime);
    }
	return ceguiSystem.injectKeyUp(keyEvent.key);
}
} /* Namespace GPE */
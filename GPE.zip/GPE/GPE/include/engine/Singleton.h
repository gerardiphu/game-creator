/**
 * Original version Copyright (C) Scott Bilas, 2000.
 * All rights reserved worldwide.
 *
 * This software is provided "as is" without express or implied
 * warranties. You may freely copy and compile this source into
 * applications you distribute provided that the copyright text
 * below is included in the resulting source code, for example:
 * "Portions Copyright (C) Scott Bilas, 2000"
 */
#ifndef _SINGLETON_H
#define _SINGLETON_H
#include <cassert>
template <typename T> class Singleton {
public:
	Singleton( void ) {
		assert( !ms_Singleton ); 
	    ms_Singleton = static_cast< T* >( this );
	}
	~Singleton( void ) {
		assert ( ms_Singleton ); 
		ms_Singleton = 0;
	}
	static T& getSingleton( void ) {
		assert ( ms_Singleton ); 
		return ( *ms_Singleton );
	}
	static T* getSingletonPointer( void ) {
		return ( ms_Singleton );
	}
protected:
	static T* ms_Singleton;
};
template <typename T> T* Singleton <T>::ms_Singleton = 0;
#endif  /* _SINGLETON_H */
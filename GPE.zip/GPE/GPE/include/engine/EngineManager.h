#ifndef _ENGINE_MANAGER_H
#define _ENGINE_MANAGER_H
/**
 * @mainpage
 *
 * This is the GPE (Game Programming Engine) documentation for version 0.19.
 */
/**
 * Copyright 2010 Gerard Prudhomme.
 *
 * @file	EngineManager.h
 * @author	Gerard Prudhomme
 * @version 0.19
 * @date	Friday, December 3, 2010
 */
/* Include section: */
#include "OgreFrameListener.h"
#include "Singleton.h"
/* Forward declarations: */
namespace Ogre { class Root; class RenderWindow; }
namespace GPE { class GuiManager; class InputManager; class WorldManager;
/**
 * @class	EngineManager
 *			This class serves as the central clearing house, as it were.
 *			
 *			Within the EngineManager class there are the instantiations of the manager objects. 
 *			This allows all classes to be accessed through the centralized EngineManager class.
 *
 *			In addition the EngineManager class	sets up the OGRE framework and handles the main loop.
 *
 * @author	Gerard Prudhomme
 * @version 0.19
 * @date	Friday, December 3, 2010
 * @see		Singleton()
 * @see		Ogre::FrameListener()
 */
class EngineManager : public Singleton <EngineManager>, public Ogre::FrameListener {
public:
	/** Constructor, sets all member variables to initialised states. */
	EngineManager();
	/** Destructor, garbage collection and clean up upon exit. */
	~EngineManager();
	/** Handles the rendering of one frame, updates messages, and serves as the main loop. */
	void tick();
	/** Get the game state, as represented by an integer.
		@return	the value of the gameState integer 
	*/
	int getGameState() { return gameState; }
	/** Accessor function to get the value of the shouldQuit boolean.
		@return true if we should quit, false otherwise.
	*/
	bool getShouldQuit() { return shouldQuit; }
	/** Accessor function to get a pointer to the renderWindow object.
		@return pointer to renderWindow object.
	*/
	Ogre::RenderWindow *getRenderWindow() { return renderWindow; }
	/** Accessor function to get a pointer to the worldManager object.
		@return pointer to worldManager object.
	*/
	GPE::WorldManager *getWorldManager() { return worldManager; }
	/** Accessor function to get a pointer to the guiManager object.
		@return pointer to guiManager object.
	*/
	GPE::GuiManager *getGuiManager() { return guiManager; }
	/** Mutator subroutine to set the value of the shouldQuit variable.
		@param value true if we should quit, or false to continue running.
	*/
	void setShouldQuit ( bool value ) { shouldQuit = value; }
private:
	/** This function is called when a frame is started, and updates animations and camera position.
		@param frameEvent the Ogre::FrameEvent object which contains frame information.
		@return whether or not frame executed successfully */
	bool frameStarted ( const Ogre::FrameEvent& frameEvent );
	/** This subroutine loads all resource locations from "data/config/resources.cfg". */
	void initialiseResourceManager();
	/** This subroutine handles all the set up apart from variable initialisation. */
	void initialise();
	/** The OGRE root object. */
	Ogre::Root *ogreRoot;
	/** The OGRE render window. */
	Ogre::RenderWindow *renderWindow;
	/** Controls the integration with Crazy Eddie's GUI Library (CEGUI). */
	GPE::GuiManager *guiManager;
	/** Controls the integration with the Object Oriented Input System Library (OIS). */
	GPE::InputManager *inputManager;
	/** Controls the 3D world, creation of objects, moving of the player, etc. */
	GPE::WorldManager *worldManager;
	/** Whether or not we should quit the application. */
	bool shouldQuit;
	/** Integer holding the game state. */
	int gameState;
};
} /* Namespace GPE */
#endif  /* _ENGINE_MANAGER_H */
#ifndef _WORLD_MANAGER_H
#define _WORLD_MANAGER_H
/**
 * Copyright 2010 Gerard Prudhomme.
 *
 * @file	WorldManager.h
 * @author	Gerard Prudhomme
 * @version 0.19
 * @date	Friday, December 3, 2010
 */
/* Include section: */
#include "OgreMath.h"
/* Forward declarations: */
namespace Ogre { class SceneNode; class AnimationState; class Entity; class SceneManager; class Camera; class Viewport; }
/**
 * @class	WorldManager
 *			Handles all controls related to the 3D world, and the movment of the player character.
 *			
 *			Within the WorldManager class are contained the component which allow the terrain to be rendered, the trees to be placed, grass, etc.
 *
 * @author	Gerard Prudhomme
 * @version 0.19
 * @date	Friday, December 3, 2010
 * @see		Singleton()
 */
namespace GPE {
class WorldManager {
public:
	/** Constructor, sets all member variables to initialised states. */
	WorldManager(); 
	/** Destructor, garbage collection and clean up upon exit. */
	~WorldManager();
	/** Handles the rendering of one frame, updates messages, and serves as the main loop. */
	void tick();
	/** Accessor function to get the value of the isPlayerMoving boolean.
		@return true if the player is moving, false otherwise.
	*/
	bool getIsPlayerMoving() { return isPlayerMoving; }
	/** Accessor function to get the value of the changePlayerAnimation boolean.
		@return true if we need to change the player's animation, false otherwise.
	*/
	bool getChangePlayerAnimation() { return changePlayerAnimation; }
	/** Accessor function to get a pointer to the animation state of the 3D character in the world scene.
		@return	pointer to the animation state of the 3D character in the world scene.
	*/
	Ogre::AnimationState *getAnimationState() { return animationState; }
	/** Accessor function to get a pointer to the model of the 3D character in the world scene.
		@return	pointer to the model of the 3D character in the world scene.
	*/
	Ogre::Entity *getModel() { return pcModel; }
	/** Accessor function to get a pointer to the model node of the 3D character in the world scene.
		@return	pointer to the model node of the 3D character in the world scene.
	*/
	Ogre::SceneNode *getModelNode() { return pcModelNode; }
	/** Accessor function to get a pointer to the scene manager for the world scene.
		@return	pointer to the scene manager for the world scene.
	*/
	Ogre::SceneManager *getSceneManager() { return sceneManager; }
	/** Mutator subroutine to set the value of the isPlayerMoving boolean.
		@param value true if the player is moving, false otherwise.
	*/
	void setIsPlayerMoving ( bool value ) { isPlayerMoving = value; }
	/** Mutator subroutine to set the where the animationState points to.
		@param value with a pointer to the animationState we wish to point to.
	*/
	void setAnimationState ( Ogre::AnimationState *value) { animationState = value; }
	/** Mutator subroutine to set the value of the changePlayerAnimation boolean.
		@param value true if we need to change the player's animation, false otherwise.
	*/
	void setChangePlayerAnimation ( bool value ) { changePlayerAnimation = value; }
	/** Mutator subroutine to modify the value of the cameraZoom Ogre::Real, and makes sure the value is not outside guidelines.
		@param value the amount of zoom we wish to modify.
	*/
	void modifyCameraZoom ( Ogre::Real value ) { cameraZoom -= value; if (cameraZoom < 10) { cameraZoom = 10; } else if (cameraZoom > 250) { cameraZoom = 250; } }
	/** Mutator subroutine to modify the value of the cameraPitch Ogre::Real.
		@param value the amount of zoom we wish to modify.
	*/
	void modifyCameraPitch ( Ogre::Real value ) { cameraPitch -= value; }
	/** Mutator subroutine to modify the value of the cameraYaw Ogre::Real.
		@param value the amount of zoom we wish to modify.
	*/
	void modifyCameraYaw ( Ogre::Real value ) { cameraYaw -= value; }
private:
	/** Handles all the set up apart from variable initialisation. */
	void initialise();
	/** Loads the grass, by randomly placing grass inside a grid on the terrain. */
	void loadGrass();
	/** Loads the trees, by randomly placing trees (with variable scale) inside a grid on the terrain. */
	void loadTrees();
	/** Creates the grass mesh, by manually creating a mesh. */
	void createGrassMesh();
	/** Is the player moving. */
	bool isPlayerMoving;
	/** Has the player's animation changed. */
	bool changePlayerAnimation;
	/** The camera yaw, pitch, and zoom. */
	Ogre::Real cameraYaw, cameraPitch, cameraZoom;
	/** The current animation state of the player. */
	Ogre::AnimationState *animationState;
	/** The player's character model. */
	Ogre::Entity *pcModel;
	/** The scene node that the player is attached to. */
	Ogre::SceneNode *pcModelNode;
	/** The scene node that the camera is attached to. */
	Ogre::SceneNode *cameraNode;
	/** The Scene Manager for the world scene. */
	Ogre::SceneManager *sceneManager;
	/** The camera object. */
	Ogre::Camera *camera;
	/** The Ogre viewport */
	Ogre::Viewport *viewport;
};
}
#endif  /* _WORLD_MANAGER_H */
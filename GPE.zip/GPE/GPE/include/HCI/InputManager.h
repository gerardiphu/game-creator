#ifndef _INPUT_MANAGER_H
#define _INPUT_MANAGER_H
/**
 * Copyright 2010 Gerard Prudhomme.
 *
 * @file	InputManager.h
 * @author	Gerard Prudhomme
 * @version 0.19
 * @date	Friday, December 3, 2010
 */
/* Include section: */
#include "OgreVector3.h"
#include "OIS\OISMouse.h"
#include "OIS\OISKeyboard.h"
/* Forward declarations: */
namespace OIS { class MouseEvent; class KeyEvent; class InputManager; }
/**
 * @class	InputManager
 *			Controls the integration with the Object Oriented Input System Library (OIS)
 *			
 *			Within the InputManager class are contained all the different objects necessary to set up and
 *			interact with OIS.
 *
 * @author	Gerard Prudhomme
 * @version 0.19
 * @date	Friday, December 3, 2010
 * @see		Singleton()
 */
namespace GPE { 
class InputManager : public OIS::MouseListener, public OIS::KeyListener {
public:
	/** Constructor, sets all member variables to initialised states. */
	InputManager(); 
	/** Destructor, garbage collection and clean up upon exit. */
	~InputManager();
	/** Sets up the boundaries of our windows. 
		@param width the width of the window.
		@param height the height of the window.
	*/
	void setWindowExtents( int width, int height ) ;
	/** Handles the rendering of one frame, updates messages, and serves as the main loop. */
	void tick();
	/** Is called whenever the mouse moves.
		@param mouseEvent OIS MouseEvent object, holds mouse x,y,z coordinates.
		@return true if the input was processed correctly, false if not.
	*/
	bool mouseMoved( const OIS::MouseEvent &mouseEvent );
	/** Is called whenever a mouse button is pressed.
		@param mouseEvent OIS MouseEvent object, holds mouse x,y,z coordinates.
		@param mouseButton OIS MouseButtonID object, holds which mouse button was clicked.
		@return true if the input was processed correctly, false if not.
	*/
	bool mousePressed( const OIS::MouseEvent &mouseEvent, OIS::MouseButtonID mouseButton );
	/** Is called whenever a mouse button is released.
		@param mouseEvent OIS MouseEvent object, holds mouse x,y,z coordinates.
		@param mouseButton OIS MouseButtonID object, holds which mouse button was clicked.
		@return true if the input was processed correctly, false if not.
	*/
	bool mouseReleased( const OIS::MouseEvent &mouseEvent, OIS::MouseButtonID mouseButton );
	/** Is called whenever a key on the keyboard is pressed.
		@param keyEvent OIS KeyEvent object, holds which key was pressed.
		@return true if the input was processed correctly, false if not.
	*/
	bool keyPressed( const OIS::KeyEvent &keyEvent );
	/** Is called whenever a key on the keyboard is released.
		@param keyEvent OIS KeyEvent object, holds which key was released.
		@return true if the input was processed correctly, false if not.
	*/
	bool keyReleased( const OIS::KeyEvent &keyEvent );
private:
	/** Handles all the set up apart from variable initialisation. */
	void initialise();
	/** The OIS Input Manager, helps to set up the OIS bindings */
	OIS::InputManager *oisInputManager;
	/** The OIS Keyboard object, digital representation of the user's keyboard. */
	OIS::Keyboard *oisKeyboard;
	/** The OIS Mouse object, digital representation of the user's mouse. */
	OIS::Mouse *oisMouse;
	/** inputTransform holds the current offset for the player character's movement. */
	Ogre::Vector3 inputTransform;
	/** The speed at which the character will rotate in the GUI. */
	float rotateSpeed;
};
} /* Namespace GPE */
#endif  /* _INPUT_MANAGER_H */
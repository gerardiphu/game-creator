#ifndef _GUI_MANAGER_H
#define _GUI_MANAGER_H
/**
 * Copyright 2010 Gerard Prudhomme.
 *
 * @file	GuiManager.h
 * @author	Gerard Prudhomme
 * @version 0.19
 * @date	Friday, December 3, 2010
 */
/* Include section: */
/* Forward declarations: */
namespace CEGUI { class LuaScriptModule; class OgreCEGUIRenderer; class System; }
namespace Ogre { class AnimationState; class SceneManager; }
/**
 * @class	GuiManager
 *			Controls the integration with Crazy Eddie's GUI Library (CEGUI).
 *			
 *			Within the GuiManager class are contained all the different objects necessary to set up and
 *			interact with CEGUI, this includes the Lua scripting module set up.
 *
 * @author	Gerard Prudhomme
 * @version 0.19
 * @date	Friday, December 3, 2010
 * @see		Singleton()
 */
namespace GPE {
class GuiManager {
public:
	/** Constructor, sets all member variables to initialised states. */
	GuiManager();
	/** Destructor, garbage collection and clean up upon exit. */
	~GuiManager();
	/** This subroutine handles the rendering of one frame, updates messages, and serves as the main loop. */
	void tick();
	/** Accessor function to get a pointer to the scriptModule object.
		@return	pointer to the scriptModule object.
	*/
	CEGUI::LuaScriptModule *getScriptModule() { return scriptModule; }
	/** Accessor function to get a pointer to the animation state of the 3D character in the RTT scene.
		@return	pointer to the animation state of the 3D character in the RTT scene.
	*/
	Ogre::AnimationState *getAnimationState() { return animationState; }
	/** Accessor function to get a pointer to the RTT scene manager.
		@return	pointer to the RTT scene manager.
	*/
	Ogre::SceneManager *getSceneManager() { return sceneManager; }
private:
	/** This subroutine handles all the set up apart from variable initialisation. */
	void initialise();
	/** This subroutine renders the 3D character to a texture, then uses texture in the GUI to give the appearance of a 3D object in a 2D interface. */
	void renderCharacter();
	/** The guiRenderer object which contains the bindings between OGRE and CEGUI. */
	CEGUI::OgreCEGUIRenderer *guiRenderer;
	/** The ceguiSystem object contains the CEGUI system. */
	CEGUI::System *ceguiSystem;
	/** The Lua script module connection. */
	CEGUI::LuaScriptModule *scriptModule;
	/** The Animation State for the GUI 3D character. */
	Ogre::AnimationState *animationState;
	/** Scene Manager for the RTT scene. */
	Ogre::SceneManager *sceneManager;
	/** The Camera Z position (how far zoomed out we are) for the RTT camera. */
	int rttCameraZ;
	/** The amount of rotation to enact on the character being displayed using the RTT scene. */
	int rttCharacterRotate;
};
} /* Namespace GPE */
#endif  /* _GUI_MANAGER_H */